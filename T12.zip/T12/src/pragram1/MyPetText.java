package pragram1;

public class MyPetText {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyPet ml=new MyPet();
		ml.eat("ţ��");
		ml.eat(4);
	}

}
