package pragram1;

public class Card {
	
	private String color; 
	private String num; //����ֵ
   public String key;//�������ݣ�
   public String getColor(){
	   return color;
   }
   public void setColor(String color){
	   this.color=color;
   }
   public String getNum(){
	   return num;
   }
   public void setNum(String num){
	   this.num=num;
   }
   public String getKey(){
	   return key;
   }
   public void setKey(String key){
	   this.key=key;
   }
   

   
   
}
